<?php get_header(); ?>



<div class="content">

	<h1 class="title">Not Found</h1>
	<p>The page you are looking is not here..</p>

</div>

<?php get_footer(); ?>