	<div class="postad">
	<?php $ad1 = get_option('dtdr_ad1'); echo stripslashes($ad1); ?>
	</div>