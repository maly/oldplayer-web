<?php
include 'theme_options.php';
if ( function_exists('register_sidebar') )
    register_sidebar(array(
	'name' => 'Sidebar',
    'before_widget' => '<div class="sidebox">',
    'after_widget' => '</div>',
	'before_title' => '<h3 class="sidetitl">',
    'after_title' => '</h3>',
    ));
if ( function_exists('register_sidebar') )
    register_sidebar(array(
	'name' => 'Footer',
    'before_widget' => '<div class="botwid">',
    'after_widget' => '</div>',
	'before_title' => '<h3 class="bothead">',
    'after_title' => '</h3>',
    ));		





if ( function_exists( 'add_theme_support' ) ) { // Added in 2.9
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'dtdr_home', 200, 100, true ); 
	add_image_size( 'dtdr_slide', 870, 280, true ); 
}

function dtdr_home_image(){

if ( has_post_thumbnail() ) {
	 the_post_thumbnail( 'dtdr_home', array('class' => 'postim') );
} else {?>
	
<?php
};

}

function dtdr_slide_image(){

if ( has_post_thumbnail() ) {
	 the_post_thumbnail( 'dtdr_slide', array('class' => 'slidim') );
} else { ?>
	<?php
};

}