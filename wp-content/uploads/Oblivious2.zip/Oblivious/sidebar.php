<div class="left">

<?php include (TEMPLATEPATH . '/searchform.php'); ?>	


<div class="sidebox">
	<h3 class="sidetitl"> Twitter Updates </h3>

<?php
$twit = get_option('dtdr_twit'); 
include('twitter.php');?>
<?php if(function_exists('twitter_messages')) : ?>
       <?php twitter_messages("$twit") ?>
       <?php endif; ?>
</div>
<div class="sidebox">
<h3 class="sidetitl"> Featured Video </h3>
<?php $vid = get_option('dtdr_video'); echo stripslashes($vid); ?>
</div>

<?php include (TEMPLATEPATH . '/sponsors.php'); ?>	

<div class="sidebar">

	<ul>
<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar("Sidebar") ) : ?>    
		<div class="sidebox">
		<li>
			<h3 class="sidetitl">Pages</h3>
			<ul>
			<?php wp_list_pages('title_li='); ?>
			</ul>
		</li>
	</div>
	
	<?php endif; ?>
	</ul>
</div>
</div>