	<div class="topad">
	<?php $ad2 = get_option('dtdr_ad2'); echo stripslashes($ad2); ?>
	</div>