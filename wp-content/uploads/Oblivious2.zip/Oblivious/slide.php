<div id="slidearea">
<ul>
	<?php 
		$gldcat = get_option('dtdr_gldcat'); 
		$gldct = get_option('dtdr_gldct');
		$my_query = new WP_Query('category_name='.$gldcat.'&showposts='.$gldct.'');
		while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
	?>
<li>
<a href="<?php the_permalink() ?>">
<?php dtdr_slide_image();?>
<span>
<p><?php the_excerpt_rss( 50, 1 ); ?> </p>
</span>
</a>
</li>
	<?php endwhile; ?>
     </ul>
</div>