jQuery(document).ready(function() {
Cufon.replace('.postleft h2,.title h2,.shout,.bothead', { fontFamily: 'Qlassik' });
Cufon.replace('h1#blog-title', { fontFamily: 'Gang of Three' });
jQuery('#slidearea').coinslider({ width: 870, height:280, delay: 5000 });
});